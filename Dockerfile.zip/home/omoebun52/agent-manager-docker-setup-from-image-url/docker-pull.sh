gcloud auth configure-docker us-west2-docker.pkg.dev
sudo docker pull \
    us-central1-docker.pkg.dev/possible-willow-385011/cloud-run-source-deploy/agent-manager/agent-manager@sha256:a0dbd24e528e1284e1a708d41c658acf13d0a3821252cf9da7cf652f3ac4b467
