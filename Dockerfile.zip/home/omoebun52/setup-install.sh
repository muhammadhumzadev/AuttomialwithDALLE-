sudo apt install unzip
unzip docker_projects_installation.zip 
sudo mv docker_projects_installation/* ~/
