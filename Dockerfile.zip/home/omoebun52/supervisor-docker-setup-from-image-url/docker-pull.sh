gcloud auth configure-docker us-west2-docker.pkg.dev
sudo docker pull \
    us-central1-docker.pkg.dev/possible-willow-385011/cloud-run-source-deploy/agent-supervsior/agent-supervsior-implementation@sha256:654659735a0936a8966ebfab0fa0a6bccfedcc446f4948e4e2b20209a40a6d44
