read -p "Enter your public IP address: " external_ip_address
echo ""
echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   React App    >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
sudo rm -rf react-app/
git clone https://github.com/After-Flea/react-app.git
cd ~/react-app/src/
rm -rf global.js
cat > global.js << EOL
module.exports = {
        AGENT_SUPERVISOR: "http://${external_ip_address}:7740",
        AGENT_MANAGER: "http://${external_ip_address}:3200",
        DIGITAL_BRAIN: "http://${external_ip_address}:8000",
        AIOS_AGENT: "http://${external_ip_address}:7860",
	TRANSLATOR: "http://${external_ip_address}:8001",
        FEEDBACK: "https://docs.google.com/forms/d/e/1FAIpQLScHIKeRwjO24HwNYKMkNu3bBkE2YeuyXI0dhoFY8B9uuiYriQ/viewform"
}
EOL


echo "<<<<<<<<<<<<<<<<<< building react-app image  >>>>>>>>>>>>>>>>>"
cd ~
cd react-app/
sudo docker rm -f react-app
sudo docker build -t react-app:v1 .
sudo docker run -p 5001:3000/tcp -p 5001:3000/udp -d --name=react-app react-app:v1
