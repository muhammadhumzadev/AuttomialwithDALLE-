gcloud auth configure-docker us-west2-docker.pkg.dev
sudo docker pull \
    us-west2-docker.pkg.dev/test-v06/aios-agent-repo/aios-agent-image:v1
