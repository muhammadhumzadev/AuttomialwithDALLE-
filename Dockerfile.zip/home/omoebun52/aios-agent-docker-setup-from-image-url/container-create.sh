sudo docker run -p 7860:7860/tcp -p 7860:7860/udp -d --name=aios-agent us-west2-docker.pkg.dev/test-v06/aios-agent-repo/aios-agent-image:v1
