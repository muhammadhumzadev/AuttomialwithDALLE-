echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   Agent manager    >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
sudo docker rm -f agent-manager
cd ~/agent-manager-docker-setup-from-image-url
bash setup.sh
bash docker-pull.sh
bash container-create.sh
echo "<external-ipaddress>:3200"

echo ""
echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   AIOS Agent   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
sudo docker rm -f aios-agent
cd ~/aios-agent-docker-setup-from-image-url
bash docker-pull.sh
bash container-create.sh
echo "<external-ipaddress>:7860"

echo ""
echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   AIOS Universal Brain    >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
sudo docker rm -f aios-universal-brain
cd ~/aios-universal-brain-docker-setup-from-image-url
bash docker-pull.sh
bash container-create.sh
echo "<external-ipaddress>:8000"

echo ""
echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   Agent Supervisor    >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
sudo docker rm -f agent-supervisor
cd ~/supervisor-docker-setup-from-image-url
bash docker-pull.sh
bash container-create.sh
echo "<external-ipaddress>:7740"

echo ""
echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   Universal Translator    >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
sudo docker rm -f translator
cd ~/whisper
bash docker-pull.sh
bash container-create.sh
echo "<external-ipaddress>:8001"


echo " <<<<<<<<< Start react setup >>>>>>"
cd ~/
bash react-docker.sh
