module.exports = {
        AGENT_SUPERVISOR: "http://34.138.53.83:7740",
        AGENT_MANAGER: "http://34.138.53.83:3200",
        DIGITAL_BRAIN: "http://34.138.53.83:8000",
        AIOS_AGENT: "http://34.138.53.83:7860",
	TRANSLATOR: "http://34.138.53.83:8001",
        FEEDBACK: "https://docs.google.com/forms/d/e/1FAIpQLScHIKeRwjO24HwNYKMkNu3bBkE2YeuyXI0dhoFY8B9uuiYriQ/viewform"
}
