sudo docker run -p 8001:8000 -d --name=django-app gcr.io/possible-willow-385011/django-app:latest


