gcloud auth configure-docker
sudo docker pull gcr.io/possible-willow-385011/django-app:latest

