gcloud auth configure-docker us-west2-docker.pkg.dev
sudo docker pull \
    us-central1-docker.pkg.dev/possible-willow-385011/cloud-run-source-deploy/aios-universal-brain/aios-universal-brain:20dbabc2f60f59526c5c0528415ee5797a3d2c95
