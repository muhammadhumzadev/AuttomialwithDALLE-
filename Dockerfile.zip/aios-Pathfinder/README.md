# aiOS Agent PathFinderGPT
PathFinder GPT

1. Set all your API Keys in textfiles
2. Set your Search Query in emfetch.py LINE 26
3. Pick Your CHATGPT Model in emfetch.py LINE 59
4. Pick Your CHATGPT Model in automail.py LINE 50
5. Set Your From Adress in automail.py LINE 67
6. Set Your MAILGUN API Url in automail.py LINE 77 & 84
7. Set Your Subject Line in automail.py in LINE 151
8. Set your Recipiens in recipients.txt divided by ,

First run emfetch.py then automail.py

